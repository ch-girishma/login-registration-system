const express = require('express');
const { MongoClient } = require('mongodb');

const app = express();
const port = 3000;

const mongoURI = 'mongodb://127.0.0.1:27017/girishma';
const dbName = 'girishma';

let db;

// Connect to MongoDB
MongoClient.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {
    if (err) {
        console.error('Error connecting to MongoDB:', err);
    } else {
        console.log('Connected to MongoDB');
        db = client.db(dbName);
    }
});

app.use(express.static('public'));
app.use(express.json());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/register', (req, res) => {
    const { register_username, register_email, register_password } = req.body;
    
    if (!register_username || !register_email || !register_password) {
        return res.status(400).send('Invalid registration data');
    }

    const collection = db.collection('users');

    // Check if the email already exists in the database
    collection.findOne({ email: register_email }, (err, user) => {
        if (err) {
            console.error('Error checking existing user:', err);
            res.status(500).send('Internal Server Error');
        } else if (user) {
            res.status(400).send('Email already exists');
        } else {
            // If the email is not in use, insert the new user
            collection.insertOne({ username: register_username, email: register_email, password: register_password }, (err, result) => {
                if (err) {
                    console.error('Error inserting document:', err);
                    res.status(500).send('Internal Server Error');
                } else {
                    res.status(200).send('Registration successful!');
                }
            });
        }
    });
});

app.post('/login', (req, res) => {
    const { login_email, login_password } = req.body;

    if (!login_email || !login_password) {
        return res.status(400).send('Invalid login data');
    }

    const collection = db.collection('users');

    collection.findOne({ email: login_email, password: login_password }, (err, user) => {
        if (err) {
            console.error('Error finding user:', err);
            res.status(500).send('Internal Server Error');
        } else if (user) {
            res.status(200).send('Login successful! Redirecting to another page.');
        } else {
            res.status(401).send('Invalid login details.');
        }
    });
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
