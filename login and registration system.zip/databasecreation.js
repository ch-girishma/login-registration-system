const express = require('express');
const { MongoClient } = require('mongodb');

const app = express();
const port = 3001;

const mongoURI = 'mongodb://127.0.0.1:27017/myproject';
const dbName = 'myproject';

let db;

// Connect to MongoDB
MongoClient.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {
    if (err) {
        console.error('Error connecting to MongoDB:', err);
    } else {
        try {
            console.log('Connected to MongoDB');
            db = client.db(dbName);
        } catch (error) {
            console.error('Error setting up the database:', error);
        }
    }
});

app.use(express.static('public'));
app.use(express.json());

// ... rest of your code
